﻿Water Heating Lab — source code

Files:
  boiling-water/index.html
  boiling-water/app.js
  boiling-water/styles.css
  shared/s3phy-embed.css
  shared/s3phy-embed-init.js
  shared/s3phy-tokens.css

To open after unzip: open boiling-water/index.html in a browser.
